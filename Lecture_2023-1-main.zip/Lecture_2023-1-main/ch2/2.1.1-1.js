// if (true) {
//   var x = 3;
// }
// console.log(x); // 3

if (true) {
  let y = 3;
}
y = 2;
console.log(y); // Uncaught ReferenceError: y is not defined
