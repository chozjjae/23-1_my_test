const array = ['nodejs', {}, 10, true];
const [node, obj, , bool] = array;
