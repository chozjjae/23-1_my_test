{ name: name, age: age } // ES5
{ name, age } // ES2015
