var num1 = 1;
var num2 = 2;
var result = num1 + num2;
var string1 = num1 + ' 더하기 ' + num2 + '는 \'' + result + '\'';
console.log(string1); // 1 더하기 2는 '3'
