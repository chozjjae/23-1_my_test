const passport = require('passport');

passport.hello = 'whatever';

console.log(cache);
