const cache = require('./cache');
cache.message = '캐싱됩니다!';
