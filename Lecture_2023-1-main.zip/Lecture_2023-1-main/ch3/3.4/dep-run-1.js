const { dep1 } = require('./dep1-1');
const { dep2 } = require('./dep2-1');

dep1();
dep2();

