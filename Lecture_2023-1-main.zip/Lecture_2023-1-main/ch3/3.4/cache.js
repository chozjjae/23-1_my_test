module.exports = {
  name: '캐시',
};
