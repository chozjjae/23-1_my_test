console.log(__filename);
console.log(__dirname);
