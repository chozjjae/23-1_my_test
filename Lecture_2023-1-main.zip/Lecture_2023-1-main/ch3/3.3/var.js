// const odd = '홀수입니다';
// const even = '짝수입니다';

exports.odd = '홀수입니다';
exports.even = '짝수입니다';

// module.exports = {
//   odd,
//   even,
// };
