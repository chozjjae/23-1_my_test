import { odd, even } from "./var.mjs";
// import { checkOddOrEven : checkNumber } from ('./func.mjs');
import { checkOddOrEven as checkNumber } from './func.mjs';

function checkStringOddOrEven(str) {
  if (str.length % 2) { // 홀수면
    return odd;
  }
  return even;
}

console.log(checkNumber(10));
console.log(checkStringOddOrEven('hello'));
