const odd = '홀수입니다';
const even = '짝수입니다';

module.exports = {
  odd,
  even,
};
