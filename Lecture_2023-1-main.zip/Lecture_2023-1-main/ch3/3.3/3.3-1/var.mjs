const odd = '홀수입니다';
const even = '짝수입니다';

export {
  odd,
  even,
};
