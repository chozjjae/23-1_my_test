const a = false;
if (a) {
    const b = require('./func');
}
console.log('성공');