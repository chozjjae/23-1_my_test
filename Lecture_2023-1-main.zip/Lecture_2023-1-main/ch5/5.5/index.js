module.exports = () => {
  return 'hello package';
};
