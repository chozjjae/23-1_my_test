# Lecture_2023-1
2023년 1학기 강의 실습 예제 등

실습 예제는 강의 해당 주차 시작전에 업로드예정이며, 필요시 다운로드 받아 사용하시면 됩니다.
또는 교재의 저자 github(https://github.com/ZeroCho/nodejs-book) 를 이용하셔도 됩니다.
